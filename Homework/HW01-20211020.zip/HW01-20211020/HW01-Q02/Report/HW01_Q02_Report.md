# Homework 01

## Question 2

for MEG304301

張皓鈞 B11030202



Convert this program from Python2 to Python3

![Readme-HW1-Q2-Py2toPy3-Details](/Users/hao/Documents/GitHub/MEG304301-Python/Homework/HW01-20211020/HW01-Q02/Report/Img/Readme-HW1-Q2-Py2toPy3-Details.png)



## Tests & Results

### Set n to 30

![截圖 2021-10-31 下午8.35.10](/Users/hao/Documents/GitHub/MEG304301-Python/Homework/HW01-20211020/HW01-Q02/Report/Img/截圖 2021-10-31 下午8.35.10.png)

### Set n to 45

![截圖 2021-10-31 下午8.35.57](/Users/hao/Documents/GitHub/MEG304301-Python/Homework/HW01-20211020/HW01-Q02/Report/Img/截圖 2021-10-31 下午8.35.57.png)

### Set n to 111

![截圖 2021-10-31 下午8.36.50](/Users/hao/Documents/GitHub/MEG304301-Python/Homework/HW01-20211020/HW01-Q02/Report/Img/截圖 2021-10-31 下午8.36.50.png)

